package com.android.basketballcounter

class OpenWeatherResponse {
    lateinit var weather: ArrayList<WeatherItem>

    lateinit var main: TemperatureItem
}