package com.android.basketballcounter

data class Team(val teamName: String) {
    var points: Int = 0
}